# node-template-project

## Стартовый шаблон node.js
